# EcoFest Restaurant - Quick Start Guide

## Project Overview

A complete restaurant platform with eco-friendly features including food ordering, table booking, event booking, food donation, and an eco-rewards system.

## Tech Stack

- **Frontend**: React 18 with Vite
- **Backend**: Spring Boot 3.5.8
- **Database**: MySQL
- **Ports**: Frontend (5173), Backend (8080)

## Setup Instructions

### Backend Setup

1. **Configure Database**
   - Update `src/main/resources/application.properties` with your MySQL credentials:
     ```properties
     spring.datasource.url=jdbc:mysql://localhost:3306/restaurant_ecofest
     spring.datasource.username=your_username
     spring.datasource.password=your_password
     ```

2. **Create Database**
   ```sql
   CREATE DATABASE restaurant_ecofest;
   ```

3. **Run Backend**
   ```bash
   ./mvnw spring-boot:run
   ```
   Or use your IDE to run `RestaurantEcofestApplication.java`

   The backend will run on `http://localhost:8080`

### Frontend Setup

1. **Navigate to Frontend Directory**
   ```bash
   cd frontend
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

3. **Start Development Server**
   ```bash
   npm run dev
   ```

   The frontend will run on `http://localhost:5173`

## Features Implemented

### ✅ User Authentication
- Sign up with full name, email, phone number, and password
- Login with email and password
- Session management

### ✅ Food Ordering
- Browse menu items
- Add to cart with quantity control
- Apply eco-rewards discount (10% of points, max 20% off)
- Place orders

### ✅ Table Booking
- Select date and time
- Choose number of guests
- Add special requests
- Earn 10 reward points on booking

### ✅ Event Booking
- Select event type (Birthday, Anniversary, Corporate Meeting, etc.)
- Choose date, time, and guest count
- Dynamic pricing based on event type and guests
- Earn reward points based on total amount

### ✅ Food Donation
- Submit food donation details
- Specify number of servings
- Earn 5 points per serving

### ✅ Eco Rewards System
- View current reward points balance
- Submit eco-friendly activities:
  - Plant a Tree (50 points)
  - Cycle to Restaurant (25 points)
  - Carpool (15 points)
  - Use Reusable Container (10 points)
  - Use Public Transport (20 points)
- Upload proof images
- View transaction history

### ✅ UI/UX Features
- Green eco-friendly theme
- Responsive design (mobile-friendly)
- Modern, professional design
- Smooth animations and transitions
- Search functionality in navbar

## API Endpoints

### Authentication
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - User login

### Orders
- `POST /api/orders` - Place food order

### Bookings
- `POST /api/bookings/table` - Book a table
- `POST /api/bookings/event` - Book an event

### Donations
- `POST /api/donations` - Submit food donation

### Rewards
- `GET /api/rewards/balance/{userId}` - Get reward points balance
- `GET /api/rewards/history/{userId}` - Get transaction history
- `POST /api/rewards/submit` - Submit eco activity with image

## File Structure

```
restaurant-ecofest/
├── frontend/                    # React frontend
│   ├── src/
│   │   ├── components/         # Navbar, Footer
│   │   ├── pages/              # All page components
│   │   ├── services/           # API service layer
│   │   └── utils/              # Auth utilities
│   └── package.json
│
└── src/main/java/.../          # Spring Boot backend
    ├── controller/             # REST controllers
    ├── service/                # Business logic
    ├── repository/             # Data access
    ├── model/                  # Entity models
    └── dto/                    # Data transfer objects
```

## Default Configuration

- Backend runs on port 8080
- Frontend runs on port 5173
- CORS is enabled for frontend origin
- Database auto-update is enabled (creates/updates tables automatically)

## Notes

1. **Image Upload**: The eco-rewards image upload feature is implemented in the frontend. The backend accepts the image but stores it in memory. For production, implement proper file storage (AWS S3, local filesystem, etc.).

2. **Phone Number**: Added phone number support to User model and SignupRequest.

3. **Reward Points**: Points are automatically calculated:
   - Food orders: 1 point per ₹100
   - Table booking: 10 points
   - Event booking: 1 point per ₹100
   - Food donation: 5 points per serving
   - Eco activities: Variable (see activities list)

4. **Eco Rewards Discount**: Users can apply eco-rewards for discounts on food orders:
   - Discount = 10% of available points
   - Maximum discount = 20% of order total

## Troubleshooting

1. **Backend won't start**: Check MySQL connection settings in `application.properties`
2. **Frontend can't connect to backend**: Ensure backend is running on port 8080
3. **CORS errors**: Verify CORS configuration in controllers matches frontend URL
4. **Database errors**: Ensure MySQL is running and database exists

## Next Steps

1. Run both backend and frontend
2. Create a user account
3. Explore all features
4. Customize styling and content as needed

Enjoy your EcoFest platform! 🌱

