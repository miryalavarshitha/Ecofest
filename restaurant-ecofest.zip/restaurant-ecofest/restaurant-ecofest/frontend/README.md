# EcoFest Restaurant Frontend

A modern React application for the EcoFest restaurant platform - an eco-friendly dining experience with table booking, food ordering, event booking, food donation, and eco-rewards system.

## Features

- 🌱 **User Authentication** - Sign up and login with email and password
- 🍽️ **Food Ordering** - Browse menu, add items to cart, and pre-order meals with eco-rewards discounts
- 🪑 **Table Booking** - Reserve tables with date, time, and guest count
- 🎉 **Event Booking** - Book events with customizable packages
- ❤️ **Food Donation** - Donate food and earn eco-rewards
- ⭐ **Eco Rewards System** - Submit eco-friendly activities, upload proof images, and earn reward points
- 💚 **Green Theme** - Beautiful, modern UI with eco-friendly green color scheme

## Tech Stack

- **React 18** - UI library
- **React Router** - Routing
- **Axios** - HTTP client
- **Vite** - Build tool and dev server

## Setup Instructions

1. **Install Dependencies**
   ```bash
   cd frontend
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```

   The app will run on `http://localhost:5173`

3. **Build for Production**
   ```bash
   npm run build
   ```

## Backend Connection

The frontend is configured to connect to the Spring Boot backend running on `http://localhost:8080`.

Make sure your backend is running before using the frontend application.

## Project Structure

```
frontend/
├── src/
│   ├── components/       # Reusable components (Navbar, Footer)
│   ├── pages/            # Page components
│   │   ├── Home.jsx
│   │   ├── FoodOrdering.jsx
│   │   ├── TableBooking.jsx
│   │   ├── EventBooking.jsx
│   │   ├── FoodDonation.jsx
│   │   ├── EcoRewards.jsx
│   │   ├── Login.jsx
│   │   └── Signup.jsx
│   ├── services/         # API service layer
│   │   └── api.js
│   ├── utils/            # Utility functions
│   │   └── auth.js
│   ├── App.jsx           # Main app component
│   └── main.jsx          # Entry point
├── package.json
└── vite.config.js
```

## API Endpoints

The frontend communicates with the following backend endpoints:

- `POST /api/auth/signup` - User registration
- `POST /api/auth/login` - User login
- `POST /api/orders` - Place food order
- `POST /api/bookings/table` - Book a table
- `POST /api/bookings/event` - Book an event
- `POST /api/donations` - Submit food donation
- `GET /api/rewards/balance/{userId}` - Get reward points balance
- `GET /api/rewards/history/{userId}` - Get reward transaction history
- `POST /api/rewards/submit` - Submit eco activity with image

## Environment Configuration

Update the API base URL in `src/services/api.js` if your backend runs on a different port or domain.

## Features in Detail

### Authentication
- Sign up with full name, email, phone number, and password
- Login with email and password
- Session management using localStorage

### Food Ordering
- Browse menu items with images and prices
- Add items to cart with quantity control
- Apply eco-rewards for discounts (10% of points, max 20% off)
- Checkout and place orders

### Eco Rewards
- View current reward points balance
- Submit eco-friendly activities:
  - Plant a Tree (50 points)
  - Cycle to Restaurant (25 points)
  - Carpool (15 points)
  - Use Reusable Container (10 points)
  - Use Public Transport (20 points)
- Upload proof images
- View reward transaction history

### Responsive Design
- Mobile-friendly layout
- Modern, clean UI with green theme
- Smooth animations and transitions

## License

All rights reserved by EcoFest

