import axios from 'axios'

const API_BASE_URL = 'http://localhost:8080/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Auth API
export const authAPI = {
  signup: (data) => api.post('/auth/signup', data),
  login: (data) => api.post('/auth/login', data),
}

// Food Order API
export const foodOrderAPI = {
  placeOrder: (data) => api.post('/orders', data),
}

// Booking API
export const bookingAPI = {
  bookTable: (data) => api.post('/bookings/table', data),
  bookEvent: (data) => api.post('/bookings/event', data),
}

// Donation API
export const donationAPI = {
  donateFood: (data) => api.post('/donations', data),
}

// Rewards API
export const rewardsAPI = {
  getBalance: (userId) => api.get(`/rewards/balance/${userId}`),
  getHistory: (userId) => api.get(`/rewards/history/${userId}`),
  submitActivity: (formData) => api.post('/rewards/submit', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  }),
}

export default api

