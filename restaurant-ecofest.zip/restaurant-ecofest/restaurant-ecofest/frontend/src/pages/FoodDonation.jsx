import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { donationAPI } from '../services/api'
import { getCurrentUser } from '../utils/auth'
import './Donation.css'

const FoodDonation = () => {
  const [formData, setFormData] = useState({
    foodDetails: '',
    servings: 1,
    date: '',
    time: '',
    numberOfPeople: 1,
    contactNumber: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const user = getCurrentUser()

  useEffect(() => {
    if (!user) {
      navigate('/login')
    }
  }, [user, navigate])

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (!formData.foodDetails || !formData.contactNumber) {
      setError('Please fill in all required fields')
      return
    }

    setLoading(true)

    try {
      await donationAPI.donateFood({
        userId: user.id,
        foodDetails: formData.foodDetails,
        servings: parseInt(formData.servings),
      })

      alert('Food donation registered successfully! Thank you for your contribution. You earned eco-rewards!')
      setFormData({
        foodDetails: '',
        servings: 1,
        date: '',
        time: '',
        numberOfPeople: 1,
        contactNumber: '',
      })
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to register donation. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="donation-page">
      <div className="page-header">
        <h1>Food Donation</h1>
        <p>Make a difference by donating food to help those in need</p>
      </div>

      <div className="donation-container">
        <div className="donation-info">
          <h2>Why Donate Food?</h2>
          <ul>
            <li>🌱 Help reduce food waste</li>
            <li>❤️ Support your community</li>
            <li>⭐ Earn eco-rewards points (5 points per serving)</li>
            <li>🌍 Contribute to a sustainable future</li>
          </ul>
        </div>

        <form onSubmit={handleSubmit} className="donation-form">
          {error && <div className="error-message">{error}</div>}

          <div className="form-section">
            <h2>Donation Details</h2>
            
            <div className="form-group">
              <label htmlFor="foodDetails">Food Description *</label>
              <textarea
                id="foodDetails"
                name="foodDetails"
                value={formData.foodDetails}
                onChange={handleChange}
                placeholder="Describe the food items you're donating (e.g., Fresh vegetables, Cooked meals, Packaged food, etc.)"
                rows={4}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="servings">Number of Servings *</label>
              <input
                type="number"
                id="servings"
                name="servings"
                value={formData.servings}
                onChange={handleChange}
                min="1"
                required
              />
              <small>Each serving earns you 5 eco-reward points</small>
            </div>

            <div className="form-group">
              <label htmlFor="date">Preferred Donation Date</label>
              <input
                type="date"
                id="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="time">Preferred Donation Time</label>
              <select
                id="time"
                name="time"
                value={formData.time}
                onChange={handleChange}
              >
                <option value="">Select time</option>
                <option value="09:00">9:00 AM</option>
                <option value="10:00">10:00 AM</option>
                <option value="11:00">11:00 AM</option>
                <option value="12:00">12:00 PM</option>
                <option value="14:00">2:00 PM</option>
                <option value="15:00">3:00 PM</option>
                <option value="16:00">4:00 PM</option>
                <option value="17:00">5:00 PM</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="numberOfPeople">Expected Recipients</label>
              <input
                type="number"
                id="numberOfPeople"
                name="numberOfPeople"
                value={formData.numberOfPeople}
                onChange={handleChange}
                min="1"
              />
            </div>

            <div className="form-group">
              <label htmlFor="contactNumber">Contact Number *</label>
              <input
                type="tel"
                id="contactNumber"
                name="contactNumber"
                value={formData.contactNumber}
                onChange={handleChange}
                placeholder="Enter your phone number"
                required
              />
            </div>
          </div>

          <button type="submit" className="submit-btn" disabled={loading}>
            {loading ? 'Submitting...' : 'Submit Donation'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default FoodDonation

