import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { foodOrderAPI, rewardsAPI } from '../services/api'
import { getCurrentUser } from '../utils/auth'
import './FoodOrdering.css'

const menuItems = [
  { id: 1, name: 'Paneer Butter Masala', price: 299, image: '🍛', description: 'Creamy and delicious' },
  { id: 2, name: 'Vegetable Biryani', price: 349, image: '🍚', description: 'Fragrant and flavorful' },
  { id: 3, name: 'Masala Dosa', price: 199, image: '🥞', description: 'Crispy and tasty' },
  { id: 4, name: 'Samosa', price: 49, image: '🥟', description: 'Crunchy snack' },
  { id: 5, name: 'Mango Lassi', price: 99, image: '🥤', description: 'Refreshing drink' },
  { id: 6, name: 'Gulab Jamun', price: 149, image: '🍮', description: 'Sweet dessert' },
  { id: 7, name: 'Dal Makhani', price: 259, image: '🍲', description: 'Rich and creamy' },
  { id: 8, name: 'Naan', price: 79, image: '🫓', description: 'Soft bread' },
]

const FoodOrdering = () => {
  const [cart, setCart] = useState([])
  const [rewardPoints, setRewardPoints] = useState(0)
  const [applyDiscount, setApplyDiscount] = useState(false)
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const user = getCurrentUser()

  useEffect(() => {
    if (!user) {
      navigate('/login')
      return
    }
    loadRewardPoints()
  }, [user, navigate])

  const loadRewardPoints = async () => {
    try {
      const response = await rewardsAPI.getBalance(user.id)
      setRewardPoints(response.data)
    } catch (error) {
      console.error('Failed to load reward points:', error)
    }
  }

  const addToCart = (item) => {
    const existingItem = cart.find((i) => i.id === item.id)
    if (existingItem) {
      setCart(cart.map((i) => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i))
    } else {
      setCart([...cart, { ...item, quantity: 1 }])
    }
  }

  const removeFromCart = (itemId) => {
    setCart(cart.filter((i) => i.id !== itemId))
  }

  const updateQuantity = (itemId, delta) => {
    setCart(cart.map((item) => {
      if (item.id === itemId) {
        const newQuantity = item.quantity + delta
        return newQuantity > 0 ? { ...item, quantity: newQuantity } : null
      }
      return item
    }).filter(Boolean))
  }

  const calculateTotal = () => {
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const discount = applyDiscount ? Math.min(rewardPoints * 0.1, subtotal * 0.2) : 0
    return { subtotal, discount, total: subtotal - discount }
  }

  const handleCheckout = async () => {
    if (cart.length === 0) {
      alert('Your cart is empty!')
      return
    }

    setLoading(true)
    try {
      const { total } = calculateTotal()
      const itemsDescription = cart.map(item => `${item.name} x${item.quantity}`).join(', ')
      
      await foodOrderAPI.placeOrder({
        userId: user.id,
        itemsDescription,
        totalAmount: total,
      })

      alert('Order placed successfully!')
      setCart([])
      setApplyDiscount(false)
      loadRewardPoints()
    } catch (error) {
      alert('Failed to place order. Please try again.')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  const { subtotal, discount, total } = calculateTotal()

  return (
    <div className="food-ordering">
      <div className="page-header">
        <h1>Food Ordering</h1>
        <p>Browse our menu and pre-order your favorite meals</p>
      </div>

      <div className="food-ordering-container">
        <div className="menu-section">
          <h2>Menu</h2>
          <div className="menu-items">
            {menuItems.map((item) => (
              <div key={item.id} className="menu-item">
                <div className="item-image">{item.image}</div>
                <div className="item-details">
                  <h3>{item.name}</h3>
                  <p>{item.description}</p>
                  <div className="item-price">₹{item.price}</div>
                </div>
                <button onClick={() => addToCart(item)} className="add-btn">
                  Add
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="cart-section">
          <h2>Your Order</h2>
          <div className="reward-info">
            <span>⭐ Your Eco Points: {rewardPoints}</span>
            {rewardPoints > 0 && (
              <label className="discount-toggle">
                <input
                  type="checkbox"
                  checked={applyDiscount}
                  onChange={(e) => setApplyDiscount(e.target.checked)}
                />
                Apply Eco Rewards (10% of points, max 20% off)
              </label>
            )}
          </div>

          {cart.length === 0 ? (
            <div className="empty-cart">Your cart is empty</div>
          ) : (
            <>
              <div className="cart-items">
                {cart.map((item) => (
                  <div key={item.id} className="cart-item">
                    <div className="cart-item-info">
                      <h4>{item.name}</h4>
                      <p>₹{item.price} each</p>
                    </div>
                    <div className="cart-item-controls">
                      <button onClick={() => updateQuantity(item.id, -1)}>-</button>
                      <span>{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.id, 1)}>+</button>
                      <button onClick={() => removeFromCart(item.id)} className="remove-btn">×</button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="cart-summary">
                <div className="summary-row">
                  <span>Subtotal:</span>
                  <span>₹{subtotal.toFixed(2)}</span>
                </div>
                {applyDiscount && (
                  <div className="summary-row discount-row">
                    <span>Eco Rewards Discount:</span>
                    <span>-₹{discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="summary-row total-row">
                  <span>Total:</span>
                  <span>₹{total.toFixed(2)}</span>
                </div>
              </div>

              <button onClick={handleCheckout} className="checkout-btn" disabled={loading}>
                {loading ? 'Processing...' : 'Confirm Booking & Pre-Order'}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default FoodOrdering

