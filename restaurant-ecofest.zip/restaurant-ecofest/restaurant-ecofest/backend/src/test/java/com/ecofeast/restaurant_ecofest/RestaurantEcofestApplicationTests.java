package com.ecofeast.restaurant_ecofest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantEcofestApplicationTests {

	@Test
	void contextLoads() {
	}

}
