package com.ecofeast.restaurant_ecofest.model;

public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED
}
