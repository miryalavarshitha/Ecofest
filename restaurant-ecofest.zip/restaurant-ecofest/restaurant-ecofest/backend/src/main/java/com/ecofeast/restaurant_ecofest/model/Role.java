package com.ecofeast.restaurant_ecofest.model;


public enum Role {
    USER,
    ADMIN
}

