package com.ecofeast.restaurant_ecofest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantEcofestApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantEcofestApplication.class, args);
	}

}
